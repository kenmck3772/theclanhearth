# Images Folder Instructions

REQUIRED: Place your Celtic emblem here as "clan-hearth-emblem.png"

Additional clan images can be placed in the clan-badges/ subfolder.
Name them consistently like:
- macdonald-badge.png
- campbell-badge.png
- stewart-badge.png
etc.

The website will automatically use these images when available.
