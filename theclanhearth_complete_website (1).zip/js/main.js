// The Clan Hearth - Main JavaScript File
// Interactive functionality for Scottish heritage website

// Global variables
let clansData = [];
let legendsData = [];
let locationsData = [];
let currentSearchTerm = '';

// Initialize the website when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeWebsite();
});

// Main initialization function
async function initializeWebsite() {
    try {
        // Load all data files
        await loadAllData();

        // Initialize search functionality
        initializeSearch();

        // Initialize smooth scrolling
        initializeSmoothScrolling();

        // Initialize animations
        initializeAnimations();

        // Initialize mobile menu if needed
        initializeMobileMenu();

        console.log('The Clan Hearth website initialized successfully');
    } catch (error) {
        console.error('Error initializing website:', error);
    }
}

// Load all JSON data files
async function loadAllData() {
    try {
        // Load clans data
        const clansResponse = await fetch('./content/clans.json');
        const clansJson = await clansResponse.json();
        clansData = clansJson.clans || [];

        // Load legends data
        const legendsResponse = await fetch('./content/legends.json');
        const legendsJson = await legendsResponse.json();
        legendsData = legendsJson.legends || [];

        // Load locations data
        const locationsResponse = await fetch('./content/locations.json');
        const locationsJson = await locationsResponse.json();
        locationsData = locationsJson.categories || [];

        console.log(`Loaded ${clansData.length} clans, ${legendsData.length} legends, ${locationsData.length} location categories`);
    } catch (error) {
        console.error('Error loading data files:', error);
        // Use fallback data if files can't be loaded
        initializeFallbackData();
    }
}

// Initialize search functionality
function initializeSearch() {
    const searchBar = document.getElementById('searchBar');
    const searchBtn = document.getElementById('searchBtn');

    if (searchBar) {
        // Add search event listeners
        searchBar.addEventListener('input', debounce(handleSearch, 300));
        searchBar.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                handleSearch();
            }
        });
    }

    if (searchBtn) {
        searchBtn.addEventListener('click', handleSearch);
    }
}

// Handle search functionality
function handleSearch() {
    const searchTerm = document.getElementById('searchBar').value.trim().toLowerCase();
    currentSearchTerm = searchTerm;

    if (searchTerm === '') {
        displayAllClans();
        return;
    }

    // Search through clans
    const filteredClans = clansData.filter(clan => 
        clan.name.toLowerCase().includes(searchTerm) ||
        clan.gaelic_name.toLowerCase().includes(searchTerm) ||
        clan.territory.toLowerCase().includes(searchTerm) ||
        clan.motto.toLowerCase().includes(searchTerm) ||
        clan.history.toLowerCase().includes(searchTerm)
    );

    displaySearchResults(filteredClans, searchTerm);
}

// Display search results
function displaySearchResults(results, searchTerm) {
    const clanGrid = document.querySelector('.clan-grid');
    if (!clanGrid) return;

    if (results.length === 0) {
        clanGrid.innerHTML = `
            <div class="no-results">
                <h3>No results found for "${searchTerm}"</h3>
                <p>Try searching for clan names, territories, or keywords from Scottish history.</p>
            </div>
        `;
        return;
    }

    // Display filtered results
    displayClans(results);

    // Update results count
    const resultsCount = document.createElement('div');
    resultsCount.className = 'search-results-count';
    resultsCount.innerHTML = `<p>Found ${results.length} clan${results.length !== 1 ? 's' : ''} matching "${searchTerm}"</p>`;
    clanGrid.parentNode.insertBefore(resultsCount, clanGrid);
}

// Display all clans (initial load)
function displayAllClans() {
    displayClans(clansData.slice(0, 6)); // Show first 6 clans on homepage
}

// Display clans in the grid
function displayClans(clans) {
    const clanGrid = document.querySelector('.clan-grid');
    if (!clanGrid) return;

    clanGrid.innerHTML = clans.map(clan => `
        <div class="clan-card fade-in">
            <h3>${clan.name}</h3>
            <p class="clan-motto">"${clan.motto}"</p>
            <div class="clan-badge">${clan.territory}</div>
            <p class="clan-description">${clan.history.substring(0, 150)}...</p>
            <button class="btn btn-primary" onclick="showClanDetails('${clan.name}')">Learn More</button>
        </div>
    `).join('');

    // Animate cards
    animateCards();
}

// Show detailed clan information
function showClanDetails(clanName) {
    const clan = clansData.find(c => c.name === clanName);
    if (!clan) return;

    // Create modal or navigate to clan page
    const modal = createClanModal(clan);
    document.body.appendChild(modal);

    // Add event listener to close modal
    modal.addEventListener('click', function(e) {
        if (e.target === modal || e.target.classList.contains('modal-close')) {
            modal.remove();
        }
    });
}

// Create clan details modal
function createClanModal(clan) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content">
            <button class="modal-close">&times;</button>
            <h2>${clan.name} (${clan.gaelic_name})</h2>
            <p class="clan-motto">"${clan.motto}"</p>

            <div class="clan-details">
                <h3>Territory</h3>
                <p>${clan.territory}</p>

                <h3>History</h3>
                <p>${clan.history}</p>

                <h3>Famous Members</h3>
                <ul>
                    ${clan.famous_members.map(member => `<li>${member}</li>`).join('')}
                </ul>

                <h3>Traditional Recipe</h3>
                <p>${clan.traditional_recipe}</p>

                <h3>Clan Badge</h3>
                <p>${clan.badge}</p>

                <h3>Clan Seat</h3>
                <p>${clan.seat}</p>

                <h3>Tartan</h3>
                <p>${clan.tartan}</p>
            </div>
        </div>
    `;

    return modal;
}

// Initialize smooth scrolling for navigation links
function initializeSmoothScrolling() {
    const navLinks = document.querySelectorAll('a[href^="#"]');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();

            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);

            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Initialize animations
function initializeAnimations() {
    // Intersection Observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    }, observerOptions);

    // Observe all elements that should animate
    const animatedElements = document.querySelectorAll('.clan-card, .legend-card, .section');
    animatedElements.forEach(el => observer.observe(el));
}

// Animate clan cards
function animateCards() {
    const cards = document.querySelectorAll('.clan-card');
    cards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('fade-in');
    });
}

// Initialize mobile menu (if needed)
function initializeMobileMenu() {
    const header = document.querySelector('.header');
    const navMenu = document.querySelector('.nav-menu');

    // Add mobile menu toggle if on mobile
    if (window.innerWidth <= 768) {
        const menuToggle = document.createElement('button');
        menuToggle.className = 'mobile-menu-toggle';
        menuToggle.innerHTML = '☰';
        menuToggle.addEventListener('click', () => {
            navMenu.classList.toggle('mobile-open');
        });

        header.appendChild(menuToggle);
    }
}

// Debounce function for search
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Fallback data in case JSON files can't be loaded
function initializeFallbackData() {
    clansData = [
        {
            name: 'MacDonald',
            gaelic_name: 'MacDhòmhnaill',
            motto: 'Per mare per terras (By sea and by land)',
            territory: 'Hebrides, Highlands',
            history: 'The MacDonalds are one of the largest and most famous Highland clans...',
            famous_members: ['Flora MacDonald', 'John MacDonald, 1st Lord of the Isles'],
            traditional_recipe: 'Cullen Skink - Smoked haddock soup',
            badge: 'Heather',
            seat: 'Armadale Castle',
            tartan: 'Red field with green and blue stripes'
        }
        // Add more fallback clans as needed
    ];
}

// Export functions for use in other scripts
window.ClanHearth = {
    showClanDetails,
    handleSearch,
    displayAllClans,
    loadAllData
};

// Add CSS for modal and animations
const additionalCSS = `
<style>
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 2000;
    animation: fadeIn 0.3s ease;
}

.modal-content {
    background: white;
    border-radius: 15px;
    padding: 2rem;
    max-width: 600px;
    max-height: 80vh;
    overflow-y: auto;
    position: relative;
    margin: 2rem;
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}

.modal-close {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: none;
    border: none;
    font-size: 2rem;
    cursor: pointer;
    color: #666;
}

.modal-close:hover {
    color: #000;
}

.clan-details h3 {
    color: var(--highland-green);
    margin-top: 1.5rem;
    margin-bottom: 0.5rem;
}

.clan-details ul {
    margin-left: 1rem;
}

.no-results {
    text-align: center;
    padding: 3rem;
    color: var(--stone-grey);
}

.search-results-count {
    text-align: center;
    margin-bottom: 1rem;
    color: var(--highland-green);
    font-weight: 600;
}

.mobile-menu-toggle {
    display: none;
    background: none;
    border: none;
    color: var(--parchment);
    font-size: 1.5rem;
    cursor: pointer;
}

@media screen and (max-width: 768px) {
    .mobile-menu-toggle {
        display: block;
    }

    .nav-menu {
        display: none;
        flex-direction: column;
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: var(--deep-forest);
        padding: 1rem;
    }

    .nav-menu.mobile-open {
        display: flex;
    }
}
</style>
`;

// Add the additional CSS to the document head
document.head.insertAdjacentHTML('beforeend', additionalCSS);
