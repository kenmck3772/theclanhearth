# The Clan Hearth - Complete Scottish Heritage Website
## Setup Instructions for Pork Bun Hosting

=== IMPORTANT: IMAGE SETUP ===
Your Celtic emblem must be named "clan-hearth-emblem.png" and placed in the /images/ folder.
This website is configured to use "./images/clan-hearth-emblem.png" throughout.

=== FILE STRUCTURE ===
Upload ALL files and folders to your Pork Bun hosting root directory:

theclanhearth.com/
├── index.html                  (Homepage - upload to root)
├── css/
│   ├── main.css               (Main Celtic styling)
│   └── responsive.css         (Mobile/tablet optimization)
├── js/
│   ├── main.js                (Interactive functionality)
│   └── map.js                 (Tourism map - future feature)
├── images/
│   ├── clan-hearth-emblem.png (YOUR CELTIC EMBLEM - REQUIRED!)
│   └── clan-badges/           (Folder for additional clan images)
├── content/
│   ├── clans.json             (30+ clan database)
│   ├── legends.json           (Scottish folklore data)
│   └── locations.json         (Tourism locations)
└── pages/
    ├── clans.html             (Complete clan database)
    ├── tourism.html           (Scotland travel guide)
    ├── legends.html           (Scottish legends & folklore)
    └── recipes.html           (Traditional recipes - coming soon)

=== UPLOAD INSTRUCTIONS ===

1. CLEAR YOUR PORK BUN HOSTING COMPLETELY
   - Delete all existing files in your hosting account
   - Start with a completely clean slate

2. EXTRACT THE ZIP FILE
   - Extract theclanhearth_complete_website.zip to your computer
   - You should see all the folders listed above

3. UPLOAD ALL CONTENTS
   - Upload the index.html file to your root directory
   - Upload ALL folders (css, js, images, content, pages) to your root directory
   - Maintain the exact folder structure shown above

4. ADD YOUR CELTIC EMBLEM
   - Take your Celtic emblem image file
   - Rename it to "clan-hearth-emblem.png" (exactly this name)
   - Upload it to the /images/ folder

5. TEST YOUR WEBSITE
   - Visit theclanhearth.com
   - Your Celtic emblem should now display properly
   - All navigation should work
   - Search functionality should be active

=== FEATURES INCLUDED ===

✅ COMPLETE HOMEPAGE
- Celtic-themed design with your emblem
- Hero section with "Through Fire We Are United"
- Featured clan previews
- Search functionality
- Tourism and legends previews

✅ 30+ CLAN DATABASE
- Complete profiles: MacDonald, Campbell, Stewart, MacLeod, Fraser, Gordon, etc.
- Each includes: Gaelic name, motto, territory, history, famous members, recipes
- Interactive search and filtering
- Detailed clan modals with full information

✅ SCOTTISH LEGENDS COLLECTION
- The Brahan Seer (Highland prophet)
- Rob Roy MacGregor (Folk hero)
- William Wallace & Robert the Bruce (National heroes)
- Bonnie Prince Charlie (Jacobite prince)
- Loch Ness Monster (Mythical creature)
- Stone of Destiny (Sacred relic)
- Grey Man of Ben MacDhui (Mountain spirit)

✅ TOURISM GUIDE
- Historic castles with clan connections
- Whisky distilleries across all regions
- Historic battlefields (Culloden, Bannockburn, etc.)
- Highland Games locations and dates
- Golf courses from St Andrews to Royal Dornoch
- Mythical sites and folklore locations

✅ RESPONSIVE DESIGN
- Mobile-optimized for phones and tablets
- Touch-friendly navigation
- Adaptive layouts for all screen sizes
- Dark mode support
- Print-friendly styling

✅ INTERACTIVE FEATURES
- Real-time clan search
- Detailed clan information modals
- Smooth scrolling navigation
- Animated card displays
- Mobile menu functionality

=== TECHNICAL FEATURES ===

- Clean, semantic HTML5 structure
- Modern CSS with Celtic color scheme and patterns
- JavaScript for interactive functionality
- JSON data files for easy content management
- Optimized for fast loading
- SEO-friendly structure
- Accessibility compliant

=== CONTENT MANAGEMENT ===

For non-technical users, content is stored in easy-to-edit JSON files:

- /content/clans.json - Add or modify clan information
- /content/legends.json - Update legends and folklore
- /content/locations.json - Manage tourism locations

Simply edit these files with any text editor to update content.

=== TROUBLESHOOTING ===

PROBLEM: Celtic emblem not displaying
SOLUTION: Ensure your image is named "clan-hearth-emblem.png" and uploaded to /images/

PROBLEM: Navigation links broken
SOLUTION: Ensure all folders (css, js, pages) are uploaded to root directory

PROBLEM: Search not working
SOLUTION: Ensure /content/ folder with JSON files is uploaded properly

PROBLEM: Mobile menu not working
SOLUTION: Ensure main.js file is uploaded to /js/ folder

=== SUPPORT ===

This website is designed for easy maintenance by non-technical users:
- All content is in simple JSON files
- Images use consistent naming conventions
- Clean folder structure for organization
- Comprehensive error handling

=== FUTURE ENHANCEMENTS ===

The website is designed for easy expansion:
- Interactive map functionality (map.js placeholder included)
- Additional clan profiles
- Recipe collection expansion
- Photo galleries
- Event calendar
- Clan society integration

=== COPYRIGHT & CREDITS ===

Website Design: Custom Celtic-themed design
Content: Historical Scottish clan information and folklore
Images: User-provided Celtic artwork integration
Technology: HTML5, CSS3, JavaScript, JSON data structure

Through Fire We Are United!
