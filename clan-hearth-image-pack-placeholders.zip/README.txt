# The Clan Hearth – Image Pack (Placeholders)
Generated: 2025-09-26T19:06:33.583293Z

This ZIP contains **placeholder tartan images** for 60+ clans following the site's file convention.

## Folders
- `images/tartans/` – 69 placeholder JPGs named `<id>-tartan.jpg`
- `images/emblems/` – (intentionally empty) add your crest images here as `<id>-emblem.jpg`

## Replace with Real Assets
1. Drop your real tartan swatches into `images/tartans/` using the same filenames.
2. Place your crest images into `images/emblems/` with matching `<id>-emblem.jpg` names.
3. Upload `images/` to your server (e.g., `/images/` at theclanhearth.com).

## Link Pattern (already used in your HTML)
- Emblem: `${IMAGE_BASE_URL}emblems/<id>-emblem.jpg`
- Tartan: `${IMAGE_BASE_URL}tartans/<id>-tartan.jpg`

## Files
- `image-manifest.json` – filename + expected URL mapping
- `clanData-stub.json` – paste-ready JSON objects you can merge into your `clanData` array.

## Suggested Sources for Real Tartans (check licensing)
- Wikimedia Commons – category pages for many clan tartans.
- Scottish Register of Tartans – authoritative registry; images may require permission.

