# The Clan Hearth

Static site for Scottish heritage, clans, tartans, and emblems.

## Structure
- `index.html` – main site
- `images/emblems/` – crest files as `<id>-emblem.jpg`
- `images/tartans/` – swatches as `<id>-tartan.jpg`
- `.github/workflows/pages.yml` – GitHub Pages deploy workflow

## Deploy
- Create a repo named `the-clan-hearth` on GitHub
- Push this folder to the `main` branch
- GitHub Pages will auto-deploy via the workflow

## Custom domain
- Add a `CNAME` file with your domain (e.g., `theclanhearth.com`)
- Configure DNS at your registrar (Porkbun) as documented in the repo

Generated: 2025-09-26T19:10:55.649765Z
